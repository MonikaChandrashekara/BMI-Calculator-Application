package com.example.bmi_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {


    private EditText et_weight;
    private EditText et_height_feet;
    private EditText et_height_inches;
    private TextView tv_bmi_result;
    private TextView tv_result;
    private Button bt_calculate;
    private Button bt_clear;
    private DecimalFormat f2 = new DecimalFormat("##.00");
    private boolean wflag, hflag, iflag, nwflag, nhflag, niflag = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("BMI Calculator");

        et_weight = findViewById(R.id.et_weight);
        et_height_feet = findViewById(R.id.et_feet);
        et_height_inches = findViewById(R.id.et_inches);
        bt_calculate = findViewById(R.id.bt_calculate_bmi);
        tv_result = findViewById(R.id.tv_result);
        tv_bmi_result = findViewById(R.id.tv_bmi_result);
        bt_clear = findViewById(R.id.bt_clear);

        bt_clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clear();
            }


        });


        bt_calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (et_weight.getText().toString().equals("")) {
                    et_weight.setError("Please enter a value");
                    Toast.makeText(MainActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                    tv_bmi_result.setText(R.string.tv_bmi_result);
                    tv_result.setText(R.string.tv_result_text);
                    wflag = true;
                } else {
                    et_weight.setError(null);
                    wflag = false;
                }
                if (et_height_feet.getText().toString().equals("")) {
                    et_height_feet.setError("Please enter a value");
                    Toast.makeText(MainActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                    tv_bmi_result.setText(R.string.tv_bmi_result);
                    tv_result.setText(R.string.tv_result_text);
                    hflag = true;
                } else {
                    et_height_feet.setError(null);
                    hflag = false;
                }
                if (et_height_inches.getText().toString().equals("")) {
                    et_height_inches.setError("Please enter a value");
                    Toast.makeText(MainActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                    tv_bmi_result.setText(R.string.tv_bmi_result);
                    tv_result.setText(R.string.tv_result_text);
                    iflag = true;
                } else {
                    et_height_inches.setError(null);
                    iflag = false;
                }
                if (et_weight.getText().toString().contains("-") && !wflag) {
                    et_weight.setError("Please enter a positive value");
                    Toast.makeText(MainActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                    tv_bmi_result.setText(R.string.tv_bmi_result);
                    tv_result.setText(R.string.tv_result_text);
                    nwflag = true;

                } else if (!et_weight.getText().toString().contains("-") && !wflag) {
                    et_weight.setError(null);
                    nwflag = false;

                }
                if (et_height_feet.getText().toString().contains("-") && !hflag) {
                    et_height_feet.setError("Please enter a positive value");
                    Toast.makeText(MainActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                    tv_bmi_result.setText(R.string.tv_bmi_result);
                    tv_result.setText(R.string.tv_result_text);
                    nhflag = true;

                } else if (!et_height_feet.getText().toString().contains("-") && !hflag) {
                    et_height_feet.setError(null);
                    nhflag = false;
                }
                if (et_height_inches.getText().toString().contains("-") && !iflag) {
                    et_height_inches.setError("Please enter a positive value");
                    Toast.makeText(MainActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                    tv_bmi_result.setText(R.string.tv_bmi_result);
                    tv_result.setText(R.string.tv_result_text);
                    niflag = true;

                } else if (!et_height_inches.getText().toString().contains("-") && !iflag) {
                    et_height_inches.setError(null);
                    niflag = false;
                }

                //BMI = (Weight in Pounds / (Height in inches x Height in inches)) x 703
                //1 foot = 12 inches

                if (!wflag && !hflag && !iflag && !nwflag && !nhflag && !niflag) {
                    Double feet = Double.parseDouble(et_height_feet.getText().toString());
                    Double inches = Double.parseDouble(et_height_inches.getText().toString());
                    if (Double.parseDouble(et_height_inches.getText().toString()) >= 12) {
                        et_height_inches.setError("Please enter a value less than 12");
                        Toast.makeText(MainActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                        tv_bmi_result.setText(R.string.tv_bmi_result);
                        tv_result.setText(R.string.tv_result_text);
                    } else if (Double.parseDouble(et_weight.getText().toString()) <= 0) {
                        et_weight.setError("Please enter a value greater than 0");
                        Toast.makeText(MainActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                        tv_bmi_result.setText(R.string.tv_bmi_result);
                        tv_result.setText(R.string.tv_result_text);
                    } else if (Double.parseDouble(et_height_feet.getText().toString()) == 0 && Double.parseDouble(et_height_inches.getText().toString()) == 0) {
                        et_height_feet.setError("Please enter a value greater than zero");
                        Toast.makeText(MainActivity.this, "Invalid Inputs", Toast.LENGTH_SHORT).show();
                        tv_bmi_result.setText(R.string.tv_bmi_result);
                        tv_result.setText(R.string.tv_result_text);
                    } else {
                        Double weight = Double.parseDouble(et_weight.getText().toString());
                        feet *= 12;
                        inches += feet;
                        Double BMI = (weight / (inches * inches)) * 703;
                        //Toast.makeText(MainActivity.this, BMI+"", Toast.LENGTH_SHORT).show();

                        if (BMI <= 18.5) {
                            tv_bmi_result.setText("Your BMI : " + f2.format(BMI));
                            tv_result.setText("Underweight");
                            Toast.makeText(MainActivity.this, "BMI Calculated", Toast.LENGTH_SHORT).show();
                        } else if (BMI <= 24.9 && BMI > 18.5) {
                            Log.d("bmi", "" + BMI);
                            tv_bmi_result.setText("");
                            tv_bmi_result.setText("Your BMI : " + f2.format(BMI));
                            tv_result.setText("Normal weight");
                            Toast.makeText(MainActivity.this, "BMI Calculated", Toast.LENGTH_SHORT).show();

                        } else if (BMI <= 29.9 && BMI > 25) {
                            tv_bmi_result.setText("Your BMI : " + f2.format(BMI));
                            tv_result.setText("Overweight");
                            Toast.makeText(MainActivity.this, "BMI Calculated", Toast.LENGTH_SHORT).show();

                        } else if (BMI >= 30) {
                            tv_bmi_result.setText("Your BMI : " + f2.format(BMI));
                            tv_result.setText("Obesity");
                            Toast.makeText(MainActivity.this, "BMI Calculated", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }
        });
    }

    public void clear() {
        wflag = false;
        hflag = false;
        iflag = false;
        nwflag = false;
        nhflag = false;
        niflag = false;
        tv_bmi_result.setText(R.string.tv_bmi_result);
        tv_result.setText(R.string.tv_result_text);
        et_weight.setText("");
        et_height_inches.setText("");
        et_height_feet.setText("");
        et_height_feet.setError(null);
        et_height_inches.setError(null);
        et_weight.setError(null);
    }
}
