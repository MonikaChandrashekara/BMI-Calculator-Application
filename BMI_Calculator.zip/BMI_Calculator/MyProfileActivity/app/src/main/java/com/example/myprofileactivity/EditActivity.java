package com.example.myprofileactivity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class EditActivity extends AppCompatActivity {




    RadioGroup rg_gender;
    RadioButton rb_female;
    RadioButton rb_male;
    ImageView iv_gender;
    EditText et_firstname;
    EditText et_lastname;
    Button bt_save;
    String flag_image ;


    public static String Edit_Key="edit";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);


        rg_gender=findViewById(R.id.rg_gender);
        rb_male=findViewById(R.id.rb_male);
        rb_female=findViewById(R.id.rb_female);
        iv_gender=findViewById(R.id.iv_gender);
        bt_save=findViewById(R.id.bt_save);
        et_firstname=findViewById(R.id.et_firstname);
        et_lastname =findViewById(R.id.et_lastname);

        final String fname;
        final String lname;
        final String flagGender;


        if(getIntent()!=null && getIntent().getExtras()!=null){

            final   User user = (User) getIntent().getExtras().getSerializable(DisplayActivity.Display_Key);
            flagGender= user.getGender();
            fname= user.getFname();
            lname= user.getLname();

            et_firstname.setText(fname);
            et_lastname.setText(lname);


            if(flagGender.equals("male")){
                iv_gender.setImageDrawable(getDrawable(R.drawable.male));
                rb_male.setChecked(true);
            }else if(flagGender.equals("female")){
                iv_gender.setImageDrawable(getDrawable(R.drawable.female));
                rb_female.setChecked(true);
            }


            rg_gender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup radioGroup, int i) {

                    switch(radioGroup.getCheckedRadioButtonId()){
                        case R.id.rb_female:
                            iv_gender.setImageDrawable(getDrawable(R.drawable.female));
                            flag_image="female";
                            break;

                        case R.id.rb_male:
                            iv_gender.setImageDrawable(getDrawable(R.drawable.male));
                            flag_image="male";
                            break;
                        default:
                            break;

                    }

                }
            });

            Log.d("FLAGGENDER", "onClick: " +flag_image);




            bt_save.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                  //  User newuser = new User(user.getFname(),user.getLname(),user.getGender());

                    user.fname = et_firstname.getText().toString();
                    user.lname =  et_lastname.getText().toString();

                    if(rb_female.isChecked()==true){
                        user.gender="female";
                    }
                    else if(rb_male.isChecked()==true){
                        user.gender="male";
                    }

                    User newuser = new User(user.fname,user.lname,user.gender);

                    Intent intent =new Intent(EditActivity.this,DisplayActivity.class);
                            intent.putExtra(Edit_Key,newuser);
                    setResult(RESULT_OK,intent);
                    finish();

                }


            });


        }


    }


}
