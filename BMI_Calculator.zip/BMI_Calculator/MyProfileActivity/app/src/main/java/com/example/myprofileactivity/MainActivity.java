package com.example.myprofileactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {


    RadioGroup rg_gender;
    RadioButton rb_female;
    RadioButton rb_male;
    ImageView iv_gender;
    EditText et_firstname;
    EditText et_lastname;
    Button bt_save;
    String flag_image ;
    public static  String FName_Key="Name";
    public static String LName_Key="Last";
    public static String Image_Key="flag";

    public static String Main_Key="main";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        rg_gender=findViewById(R.id.rg_gender);
        rb_male=findViewById(R.id.rb_male);
        rb_female=findViewById(R.id.rb_female);
        iv_gender=findViewById(R.id.iv_gender);
        bt_save=findViewById(R.id.bt_save);
        et_firstname=findViewById(R.id.et_firstname);
        et_lastname =findViewById(R.id.et_lastname);


        rg_gender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                switch(radioGroup.getCheckedRadioButtonId()){
                    case R.id.rb_female:
                        iv_gender.setImageDrawable(getDrawable(R.drawable.female));
                        flag_image="female";
                        break;

                    case R.id.rb_male:
                        iv_gender.setImageDrawable(getDrawable(R.drawable.male));
                        flag_image="male";
                        break;
                    default:
                        break;

                }

            }
        });




        bt_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(MainActivity.this,DisplayActivity.class);
//
//                intent.putExtra(FName_Key,et_firstname.getText().toString());
//                intent.putExtra(LName_Key,et_lastname.getText().toString());
//                intent.putExtra(Image_Key,flag_image);

               User user = new User(et_firstname.getText().toString(),et_lastname.getText().toString(),flag_image);

              //  User user = new User(name1,name2,flag_image);
                intent.putExtra(Main_Key,user);

                startActivity(intent);
                finish();


            }
        });




    }
}
