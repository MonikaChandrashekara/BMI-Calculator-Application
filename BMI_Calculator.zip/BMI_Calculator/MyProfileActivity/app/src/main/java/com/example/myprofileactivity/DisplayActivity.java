package com.example.myprofileactivity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class DisplayActivity extends AppCompatActivity {


    ImageView iv_gender;
    TextView tv_name;
    TextView tv_gender;
    Button bt_edit;
    private Log log;
    public static final int REQ_CODE =101;

    public static final String Display_Key ="display";

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);


        final User user = (User) getIntent().getExtras().getSerializable(MainActivity.Main_Key);

//        if(user!=null) Log.d("demo", "User :"+getIntent().getClass());

        logic(user);

    }

        protected void logic(final User user) {


            iv_gender= findViewById(R.id.iv_gender);
            tv_name = findViewById(R.id.tv_name);
            tv_gender=findViewById(R.id.tv_gender);
            bt_edit=(Button) findViewById(R.id.bt_edit);

            final String fname;
            final String lname;
            final String flagGender;

            // remember you may remove this stmnt below
          if (getIntent() != null && getIntent().getExtras() != null) {

                flagGender = user.getGender();
                fname = user.getFname();
                lname = user.getLname();


                tv_name.setText("Name :" + fname + " " + lname);
                tv_gender.setText(flagGender);

                log.i("demo", "FLAG" + flagGender);
                if (flagGender.equals("male")) {
                    iv_gender.setImageDrawable(getDrawable(R.drawable.male));
                } else if (flagGender.equals("female")) {
                    iv_gender.setImageDrawable(getDrawable(R.drawable.female));
                }


                bt_edit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {


                        Intent intent = new Intent(DisplayActivity.this, EditActivity.class);

                        intent.putExtra(Display_Key, user);

                        startActivityForResult(intent, REQ_CODE);


                    }
                });


           }
        }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode==REQ_CODE){
            if(resultCode==RESULT_OK){

                final   User user = (User) data.getExtras().getSerializable(EditActivity.Edit_Key);
                logic(user);





            }
        }
    }
}

